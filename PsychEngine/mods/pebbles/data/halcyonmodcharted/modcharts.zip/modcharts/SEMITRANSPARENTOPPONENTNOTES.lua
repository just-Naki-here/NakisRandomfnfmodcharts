function onUpdate(elapsed)
    
    setPropertyFromGroup('opponentStrums', 0, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 1, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 2, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 3, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 0, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 1, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 2, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 3, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 0, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 1, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 2, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 3, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 0, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 1, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 2, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 3, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 0, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 1, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 2, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 3, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 0, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 1, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 2, 'alpha', 0.3);
    
    setPropertyFromGroup('opponentStrums', 3, 'alpha', 0.3);

end