function onUpdate()
    setPropertyFromGroup('opponentStrums', 0, 'y', 150);
  
    setPropertyFromGroup('opponentStrums', 1, 'y', 250);
  
    setPropertyFromGroup('opponentStrums', 2, 'y', 350);
  
    setPropertyFromGroup('opponentStrums', 3, 'y', 450);
  
    setPropertyFromGroup('opponentStrums', 0, 'x', 0);
  
    setPropertyFromGroup('opponentStrums', 1, 'x', 0);
  
    setPropertyFromGroup('opponentStrums', 2, 'x', 0);
  
    setPropertyFromGroup('opponentStrums', 3, 'x', 0);
  
    setPropertyFromGroup('opponentStrums', 0, 'direction', 180);
  
    setPropertyFromGroup('opponentStrums', 1, 'direction', 180);
  
    setPropertyFromGroup('opponentStrums', 2, 'direction', 180);
  
    setPropertyFromGroup('opponentStrums', 3, 'direction', 180);
  
    setPropertyFromGroup('opponentStrums', 0, 'alpha', 0.2);
  
    setPropertyFromGroup('opponentStrums', 1, 'alpha', 0.2);
  
    setPropertyFromGroup('opponentStrums', 2, 'alpha', 0.2);
  
    setPropertyFromGroup('opponentStrums', 3, 'alpha', 0.2);

    setPropertyFromGroup('opponentSustain', 0, 'direction', 180)
    setPropertyFromGroup('opponentSustain', 1, 'direction', 180)
    setPropertyFromGroup('opponentSustain', 2, 'direction', 180)
    setPropertyFromGroup('opponentSustain', 3, 'direction', 180)
  end
  